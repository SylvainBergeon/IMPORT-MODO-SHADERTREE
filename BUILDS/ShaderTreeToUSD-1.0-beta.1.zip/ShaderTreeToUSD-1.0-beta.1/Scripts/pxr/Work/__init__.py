#
# Copyright 2016 Pixar
#
# Licensed under the terms set forth in the LICENSE.txt file available at
# https://openusd.org/license.
#
"""
Work

Allows for configuration of the system's multithreading subsystem.

"""

from pxr import Tf
Tf.PreparePythonModule()
del Tf
