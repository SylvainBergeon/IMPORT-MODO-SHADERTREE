# 
#====
#	Copyright (c) 2018, NVIDIA CORPORATION
#======
# 

#
# Copyright 2016 Pixar
#
# Licensed under the terms set forth in the LICENSE.txt file available at
# https://openusd.org/license.
#
from pxr import Tf
Tf.PreparePythonModule()
del Tf
